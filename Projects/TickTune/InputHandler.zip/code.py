# SPDX-FileCopyrightText: 2021 ladyada for Adafruit Industries
# SPDX-License-Identifier: MIT

import time
import board
import digitalio
import analogio
import busio
import usb_cdc

from adafruit_neokey.neokey1x4 import NeoKey1x4

import usb_midi
import adafruit_midi
from adafruit_midi.note_on import NoteOn
from adafruit_midi.note_off import NoteOff
from adafruit_midi.control_change import ControlChange

# ---- Setup ----

SLIDER_CC = 1

# Setup I2C (shared by NeoKey and MotorKit)
i2c = busio.I2C(board.SCL, board.SDA)
neokey = NeoKey1x4(i2c, addr=0x30)
slider = analogio.AnalogIn(board.D5)  # Use board.IO5 if GP5 is not defined

slider_switch = digitalio.DigitalInOut(board.D1)
slider_switch.direction = digitalio.Direction.INPUT
slider_switch.pull = digitalio.Pull.DOWN

slider_enabled = False
slider_switch_last = False

def get_slider_percent(slider):
    # Convert raw value (0-65535) to percent (0-100)
    return int((slider.value / 61046) * 100)

# Setup MIDI
midi = adafruit_midi.MIDI(
    midi_out=usb_midi.ports[1],     
    in_channel=1,  # Listen only to MIDI Channel 2
    out_channel=0  # Send on MIDI Channel 1 (you can keep this as is))
)

# MIDI note numbers for each NeoKey button
midi_notes = [0, 1, 2]

# State tracking
note_states = [False, False, False]
track_on_off = [False, False, False]
track_toggle_lock = [False, False, False]

# ---- Main Loop ----

while True:

    for i in range(4):  # Now handle 4 buttons
        if neokey[i]:
            if i == 3:
                # Fourth button: turn off all active notes
                print("Reset button pressed — turning all notes off.")
                for j in range(3):
                    if track_on_off[j]:  # Only send NoteOff if currently on
                        midi.send(NoteOn(midi_notes[j], 120))
                        note_states[j] = False
                        track_on_off[j] = False
                        track_toggle_lock[j] = False
                        print(f"Note {j} turned off.")
                time.sleep(0.2)  # debounce reset button
            else:
                note_states[i] = not note_states[i]
                if note_states[i]:
                    if not track_toggle_lock[i]:
                        track_on_off[i] = not track_on_off[i]
                    track_toggle_lock[i] = True
                    midi.send(NoteOn(midi_notes[i], 120))
                else:
                    midi.send(NoteOff(midi_notes[i], 0))
                    track_toggle_lock[i] = False
                time.sleep(0.01)


    if slider_switch.value and not slider_switch_last:
        slider_enabled = not slider_enabled
        print("Slider enabled:", slider_enabled)
        time.sleep(0.2)  # debounce

    slider_switch_last = slider_switch.value

    # Only send CC if slider is enabled
    if slider_enabled:
        slider_value = slider.value
        slider_percent = get_slider_percent(slider)
        cc_value = int((slider_percent / 100) * 127)
        midi.send(ControlChange(SLIDER_CC, cc_value))
        # Send [0, True, slider_percent] over serial
        for i in range(3):
            print(f"Sending [{i}, {track_on_off[i]}, {slider_percent}]")
            msg = f"[{i},{track_on_off[i]},{slider_percent}]\n"
            usb_cdc.data.write(msg.encode("utf-8"))


    time.sleep(0.01)