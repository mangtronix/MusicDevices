import time
import board
import busio
import re
import usb_cdc

from adafruit_motorkit import MotorKit

# ---- Setup ----

i2c = busio.I2C(board.SCL, board.SDA)
kit = MotorKit(i2c=i2c)

motor1_delay = 0.005
motor2_delay = 0.005

def measure_overhead_per_step(num_steps=100, delay=0.01, motor_id=1):
    print(f"Measuring overhead for motor {motor_id} with {num_steps} steps at {delay}s delay...")
    stepper_motor = kit.stepper1 if motor_id == 1 else kit.stepper2
    start = time.monotonic()
    for _ in range(num_steps):
        stepper_motor.onestep()
        time.sleep(delay)
    end = time.monotonic()
    total_time = end - start
    expected_time = delay * num_steps
    overhead = total_time - expected_time
    overhead_per_step = overhead / num_steps
    print("Motor:", f"stepper{motor_id}")
    print("Total time:", round(total_time, 4), "s")
    print("Expected sleep time:", round(expected_time, 4), "s")
    print("Extra overhead time:", round(overhead, 4), "s")
    print("Overhead per step:", round(overhead_per_step, 6), "s")
    predicted_total = (delay + overhead_per_step) * 2048
    print("Predicted time for full 360° spin:", round(predicted_total, 2), "seconds")
    return overhead_per_step

def calculate_sleep_delay_for_target_time(desired_seconds, overhead_per_step):
    print("Calculating delay to spin for", desired_seconds, "s")
    delay = (desired_seconds / 2048) - overhead_per_step
    if delay < 0:
        print("Warning: Desired time is too short given the overhead. Returning 0.")
        return 0
    return delay

overhead_1 = measure_overhead_per_step(num_steps=100, delay=0.001, motor_id=1)
overhead_2 = measure_overhead_per_step(num_steps=100, delay=0.001, motor_id=2)

next_motor1_time = time.monotonic()
next_motor2_time = time.monotonic()

while True:
    # --- Check for new delay values from sender ---
    if usb_cdc.data.in_waiting:
        line = usb_cdc.data.readline()
        if line:
            try:
                decoded = line.decode("utf-8").strip()
                print("Received:", decoded)
                if "[" in decoded and "]" in decoded:
                    match = re.search(r"\[[^\[\]]+\]", decoded)
                    if match:
                        try:
                            data = eval(match.group(0))
                            print("Parsed list:", data)
                            if data[0] == 0:
                                if data[1] != False:
                                    print("Motor 1 and 2 enabled")
                                    motor1_delay = 0.005
                                    motor2_delay = calculate_sleep_delay_for_target_time(80 - 0.6 * data[2], overhead_2)
                                    print("Motor delays set to:", motor1_delay, motor2_delay)
                                else:
                                    print("Motor 1 and 2 disabled")
                                    motor1_delay = None  # Stop motor 1
                                    motor2_delay = None  # Stop motor 2
                                    print("Motor 1 and 2 stopped")
                                
                        except Exception as e:
                            print("Eval error:", e)
                    else:
                        print("No valid list found in:", decoded)
            except Exception as e: 
                print("Parse error:", e)

    now = time.monotonic()
    if motor1_delay is not None and motor2_delay is not None:
        # --- Step motor 1 if it's time ---
        if now >= next_motor1_time:
            kit.stepper1.onestep()
            next_motor1_time = now + motor1_delay

        # --- Step motor 2 if it's time ---
        if now >= next_motor2_time:
            kit.stepper2.onestep()
            next_motor2_time = now + motor2_delay

    time.sleep(0.001)  # Small sleep to avoid hogging CPU